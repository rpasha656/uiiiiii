import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DocpubRoutes, DocpubModule } from './docpub/index';

@NgModule({
    declarations: [
    ],
    imports: [
        DocpubModule,

        RouterModule.forChild(DocpubRoutes)

    ],
    providers: []
})
export class UiModule {
}
