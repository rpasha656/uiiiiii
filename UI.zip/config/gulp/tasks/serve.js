var envConfig = require('../utils/env');
var runSequence = require('run-sequence');


var gulp = require('gulp');
var config = require('../config')();
var bs = require("browser-sync");

function startBrowsersync(config) {
    bsIns = bs.create();
    bsIns.init(config);
    bsIns.reload();
}

/* Start live server dev mode */
gulp.task('serve', ['build'], function () {
    runSequence('watch-files', function(){
        startBrowsersync(config.browserSync.dev);
    })
});